﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Gomoku
{
    class Cell:Button
    {
        public bool occupy = false;
        public Cell(int W,int H)
        {
            Width = W;
            Height = H;
        }
    }
}

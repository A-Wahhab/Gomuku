﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gomoku
{
    enum PLAYER { BLUE,RED};
    public partial class GomukuForm : Form
    {
        int Dim = 0, WinCount = 0;
        PLAYER Turn = PLAYER.BLUE;
        Cell[,] Cs;
        public GomukuForm()
        {
            InitializeComponent();
        }
        void LoadCells()
        {
            Cs = new Cell[Dim, Dim];
            CellsPanel.Controls.Clear();
            Cell B;
            for (int ri = 0; ri < Dim; ri++) 
            {
                for (int ci = 0; ci < Dim; ci++)
                {
                    int width = CellsPanel.Width / Dim - 7;
                    int height = CellsPanel.Height / Dim - 7;
                    B = new Cell(width,height);
                    B.Click += new System.EventHandler(this.Cell_Click); ;
                    CellsPanel.Controls.Add(B);
                    Cs[ri, ci] = B; 
                }
            }
        }
        void TurnChange()
        {
            if (Turn == PLAYER.BLUE)
                Turn = PLAYER.RED;
            else
                Turn = PLAYER.BLUE;
        }
        bool isHWin(PLAYER T)
        {
            Color C=Color.White;
            if (T == PLAYER.BLUE)
                C = Color.DarkBlue;
            else if (T == PLAYER.RED)
                C = Color.Crimson;
            int count = 0;
            for (int ri = 0; ri < Dim; ri++)
            {
                for (int ci = 0; ci < Dim; ci++)
                {
                    if (Cs[ri, ci].BackColor == C)
                            count++;
                }
                if (count == WinCount)
                    return true;
                else
                    count = 0;
            }
            return false;
        }
        bool isVWin(PLAYER T)
        {
            Color C = Color.White;
            if (T == PLAYER.BLUE)
                C = Color.DarkBlue;
            else if (T == PLAYER.RED)
                C = Color.Crimson;
            int count = 0;
            for (int ci = 0; ci < Dim; ci++)
            {
                for (int ri = 0; ri < Dim; ri++)
                {
                    if (Cs[ri, ci].BackColor == C) 
                            count++;
                }
                if (count == WinCount)
                    return true;
                else
                    count = 0;
            }
            return false;
        }
        bool isDR2LWin(PLAYER T)
        {
            Color C = Color.White;
            if (T == PLAYER.BLUE)
                C = Color.DarkBlue;
            else if (T == PLAYER.RED)
                C = Color.Crimson;
            int count = 0;
            for (int ri = 0; ri <= Dim - WinCount; ri++)
            {
                for (int ci = WinCount - 1; ci < Dim; ci++)
                {
                    count = 0;
                    for (int i = 0; i < WinCount; i++)
                        if (Cs[ri + i,ci - i].BackColor == C)
                            count++;
                    if (count == WinCount)
                        return true;
                }
            }
            return false;
        }
        bool isDL2RWin(PLAYER T)
        {
            Color C = Color.White;
            if (T == PLAYER.BLUE)
                C = Color.DarkBlue;
            else if (T == PLAYER.RED)
                C = Color.Crimson;
            int count = 0;
            for (int ri = 0; ri <= Dim - WinCount; ri++)
            {
                for (int ci = 0; ci <= Dim - WinCount; ci++)
                {
                    for (int i = 0; i < WinCount; i++)
                        if (Cs[ri + i, ci + i].BackColor == C) 
                            count++;
                    if (count == WinCount)
                        return true;
                    else
                        count = 0;
                }
            }
            return false;
        }
        bool isWin(PLAYER T)
        {
            return (isHWin(T) || isVWin(T) || isDL2RWin(T) || isDR2LWin(T));
        }
        bool Draw()
        {
            for (int ri = 0; ri < Dim; ri++)
                for (int ci = 0; ci < Dim; ci++)
                    if (Cs[ri,ci].occupy == false)
                        return false;
            return true;
        }
        private void Cell_Click(object sender, EventArgs e)
        {
            Cell B = (Cell)sender;
            if (B.occupy)
            {
                MessageBox.Show("Cheater!!!");
                return;
            }
            if (Turn == PLAYER.BLUE)
                B.BackColor = Color.DarkBlue;
            else if (Turn == PLAYER.RED)
                B.BackColor = Color.Crimson;
            B.occupy = true;
            if(isWin(Turn))
            {
                MessageBox.Show(Turn.ToString() + " has won the match!!!");
                CellsPanel.Controls.Clear();
                StartGame.Text = "Replay";
            }
            if(Draw())
            {
                MessageBox.Show("Match was a Draw");
                CellsPanel.Controls.Clear();
                StartGame.Text = "Replay";
            }
            TurnChange();
        }
        private void StartGame_Click(object sender, EventArgs e)
        {
            //int d = Int32.Parse(DimBox.Text);//Can't create the box
            //Dim = d;
            if (threeXthree.Checked)
                Dim = 3;
            else if (fiveXfive.Checked)
                Dim = 5;
            else if (tenXten.Checked)
                Dim = 10;
            else if (nineteenXnineteen.Checked)
                Dim = 19;
            if (Dim == 0)
            {
                MessageBox.Show("Incorrect.... Select a Option..");
                return;
            }
            if(WinningCount.Text!="")
                WinCount = Int32.Parse(WinningCount.Text);
            if (WinCount <= 0 || WinCount > Dim)
            {
                MessageBox.Show("Incorrect....Win Count");
                return;
            }
            LoadCells();
        }
    }
}

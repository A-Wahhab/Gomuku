﻿namespace Gomoku
{
    partial class GomukuForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.threeXthree = new System.Windows.Forms.RadioButton();
            this.tenXten = new System.Windows.Forms.RadioButton();
            this.fiveXfive = new System.Windows.Forms.RadioButton();
            this.nineteenXnineteen = new System.Windows.Forms.RadioButton();
            this.Options = new System.Windows.Forms.Panel();
            this.StartGame = new System.Windows.Forms.Label();
            this.Header = new System.Windows.Forms.Label();
            this.WinningCount = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CellsPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.Options.SuspendLayout();
            this.SuspendLayout();
            // 
            // threeXthree
            // 
            this.threeXthree.AutoSize = true;
            this.threeXthree.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.threeXthree.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.threeXthree.Location = new System.Drawing.Point(118, 60);
            this.threeXthree.Name = "threeXthree";
            this.threeXthree.Size = new System.Drawing.Size(82, 34);
            this.threeXthree.TabIndex = 1;
            this.threeXthree.TabStop = true;
            this.threeXthree.Text = "3 x 3";
            this.threeXthree.UseVisualStyleBackColor = true;
            // 
            // tenXten
            // 
            this.tenXten.AutoSize = true;
            this.tenXten.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.tenXten.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tenXten.Location = new System.Drawing.Point(386, 60);
            this.tenXten.Name = "tenXten";
            this.tenXten.Size = new System.Drawing.Size(106, 34);
            this.tenXten.TabIndex = 3;
            this.tenXten.TabStop = true;
            this.tenXten.Text = "10 x 10";
            this.tenXten.UseVisualStyleBackColor = true;
            // 
            // fiveXfive
            // 
            this.fiveXfive.AutoSize = true;
            this.fiveXfive.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.fiveXfive.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fiveXfive.Location = new System.Drawing.Point(248, 60);
            this.fiveXfive.Name = "fiveXfive";
            this.fiveXfive.Size = new System.Drawing.Size(82, 34);
            this.fiveXfive.TabIndex = 2;
            this.fiveXfive.TabStop = true;
            this.fiveXfive.Text = "5 x 5";
            this.fiveXfive.UseVisualStyleBackColor = true;
            // 
            // nineteenXnineteen
            // 
            this.nineteenXnineteen.AutoSize = true;
            this.nineteenXnineteen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.nineteenXnineteen.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nineteenXnineteen.Location = new System.Drawing.Point(541, 60);
            this.nineteenXnineteen.Name = "nineteenXnineteen";
            this.nineteenXnineteen.Size = new System.Drawing.Size(106, 34);
            this.nineteenXnineteen.TabIndex = 4;
            this.nineteenXnineteen.TabStop = true;
            this.nineteenXnineteen.Text = "19 x 19";
            this.nineteenXnineteen.UseVisualStyleBackColor = true;
            // 
            // Options
            // 
            this.Options.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.Options.Controls.Add(this.nineteenXnineteen);
            this.Options.Controls.Add(this.tenXten);
            this.Options.Controls.Add(this.fiveXfive);
            this.Options.Controls.Add(this.threeXthree);
            this.Options.Controls.Add(this.Header);
            this.Options.Controls.Add(this.StartGame);
            this.Options.Controls.Add(this.WinningCount);
            this.Options.Controls.Add(this.label1);
            this.Options.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Options.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Options.Location = new System.Drawing.Point(2, 1);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(792, 173);
            this.Options.TabIndex = 1;
            // 
            // StartGame
            // 
            this.StartGame.AutoSize = true;
            this.StartGame.BackColor = System.Drawing.Color.SlateBlue;
            this.StartGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.StartGame.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.StartGame.Location = new System.Drawing.Point(541, 108);
            this.StartGame.Name = "StartGame";
            this.StartGame.Size = new System.Drawing.Size(165, 38);
            this.StartGame.TabIndex = 5;
            this.StartGame.Text = "Start Game";
            this.StartGame.Click += new System.EventHandler(this.StartGame_Click);
            // 
            // Header
            // 
            this.Header.AutoSize = true;
            this.Header.BackColor = System.Drawing.Color.SlateBlue;
            this.Header.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Header.Location = new System.Drawing.Point(269, 8);
            this.Header.Name = "Header";
            this.Header.Size = new System.Drawing.Size(243, 45);
            this.Header.TabIndex = 6;
            this.Header.Text = "Gomuku Game";
            this.Header.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // WinningCount
            // 
            this.WinningCount.BackColor = System.Drawing.Color.SlateBlue;
            this.WinningCount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WinningCount.Location = new System.Drawing.Point(118, 110);
            this.WinningCount.Name = "WinningCount";
            this.WinningCount.Size = new System.Drawing.Size(109, 39);
            this.WinningCount.TabIndex = 0;
            this.WinningCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(0, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Win Count";
            // 
            // CellsPanel
            // 
            this.CellsPanel.BackColor = System.Drawing.Color.DimGray;
            this.CellsPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CellsPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CellsPanel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CellsPanel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.CellsPanel.Location = new System.Drawing.Point(3, 176);
            this.CellsPanel.Name = "CellsPanel";
            this.CellsPanel.Size = new System.Drawing.Size(791, 535);
            this.CellsPanel.TabIndex = 7;
            // 
            // GomukuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(796, 712);
            this.Controls.Add(this.CellsPanel);
            this.Controls.Add(this.Options);
            this.Name = "GomukuForm";
            this.Text = "My Gomuku";
            this.Options.ResumeLayout(false);
            this.Options.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton threeXthree;
        private System.Windows.Forms.RadioButton tenXten;
        private System.Windows.Forms.RadioButton fiveXfive;
        private System.Windows.Forms.RadioButton nineteenXnineteen;
        private System.Windows.Forms.Panel Options;
        private System.Windows.Forms.Label StartGame;
        private System.Windows.Forms.Label Header;
        private System.Windows.Forms.TextBox WinningCount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel CellsPanel;
    }
}

